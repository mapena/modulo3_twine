def multiplicar(n1,n2):
    print("version 1.0.0")
    return (n1*n2)
