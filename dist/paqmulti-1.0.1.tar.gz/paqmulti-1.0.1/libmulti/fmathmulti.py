def multiplicar(n1,n2):
    print("version 1.0.0")
    return (n1*n2)

def multiplicar1.0.1(n1,n2):
    print("version 1.0.1")
    return (n1*n2)
