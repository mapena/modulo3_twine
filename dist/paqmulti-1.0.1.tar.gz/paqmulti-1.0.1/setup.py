#from setuptools import setup
import setuptools

#with open("README.md", "r") as fh:
#    long_description = fh.read()
#packages=setuptools.find_packages(),
setuptools.setup(
      name="paqmulti",
      version="1.0.1",
      description="ejemplo de setup inicial3",
      author="mp",
      author_email="mp@mp.com.ar",
      url="www.sarasa.com.ar",
      packages=["libmulti"],
      classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
      ]

)